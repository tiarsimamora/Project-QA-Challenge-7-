package binar;

public enum fileType {
    PNG,
    JPG,
    JPEG
}